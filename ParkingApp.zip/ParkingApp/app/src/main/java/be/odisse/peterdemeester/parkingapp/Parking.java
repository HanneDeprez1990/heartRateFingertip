package be.odisse.peterdemeester.parkingapp;

/**
 * Created by peter.demeester on 29/10/2015.
 */
public class Parking {

    private String availableCapacity;
    private String name;
    private String description;
    private String address;
    private int totalCapacity;

    public Parking(String name, String description, String address, String availableCapacity, int totalCapacity){
        this.address = address;
        this.name = name;
        this.description = description;
        this.availableCapacity = availableCapacity;
        this.totalCapacity = totalCapacity;
    }

    public int getTotalCapacity() {
        return totalCapacity;
    }

    public void setTotalCapacity(int totalCapacity) {
        this.totalCapacity = totalCapacity;
    }

    public String getAvailableCapacity() {
        return availableCapacity;
    }

    public void setAvailableCapacity(String availableCapacity) {
        this.availableCapacity = availableCapacity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


    public String toString(){
        return this.name + " " + this.description + " " + this.availableCapacity + " / " + this.totalCapacity;
    }
}
