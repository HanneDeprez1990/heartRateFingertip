package be.odisse.peterdemeester.parkingapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);
        new getData().execute();
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/




    public void getParkings(View view){
        //do something
        //Intent intent = new Intent(this, DisplayMessageActivity.class);
        System.out.println("test");
        new getData().execute();
    }

    public class getData extends AsyncTask<String, String, String> {

        private HttpURLConnection urlConnection;

        @Override
        protected String doInBackground(String... args) {

            StringBuilder result = new StringBuilder();

            try {
                URL url = new URL("http://datatank.gent.be/Mobiliteitsbedrijf/Parkings11.json");
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());

                BufferedReader reader = new BufferedReader(new InputStreamReader(in));

                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

            }catch( Exception e) {
                e.printStackTrace();
            }
            finally {
                urlConnection.disconnect();
            }


            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {

            //Do something with the JSON string
            System.out.println(result);
            List<Parking> parkings = new ArrayList<Parking>();
            JSONObject jsonObject = null;
            JSONArray array = null;
            try {
                jsonObject = new JSONObject(result);
                array = jsonObject.getJSONObject("Parkings11").getJSONArray("parkings");
                for (int i = 0; i< array.length(); i++){
                    JSONObject jObject = array.getJSONObject(i);
                    String name = jObject.getString("name");
                    String description = jObject.getString("description");
                    String address = jObject.getString("address");
                    String availableCap = array.getJSONObject(i).getString("availableCapacity");
                    //int availableCap = array.getJSONObject(i).getInt("availableCapacity");
                    int totalCap = array.getJSONObject(i).getInt("totalCapacity");
                    parkings.add(new Parking(name, description, address, availableCap, totalCap ));

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            arrayAdapter = new ArrayAdapter(getBaseContext(), android.R.layout.simple_list_item_1, parkings);
            listView.setAdapter(arrayAdapter);

        }

    }

}
